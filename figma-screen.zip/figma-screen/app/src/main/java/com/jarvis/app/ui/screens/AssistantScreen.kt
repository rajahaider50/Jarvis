package com.jarvis.app.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.jarvis.app.data.DeviceControl
import com.jarvis.app.data.Prefs
import com.jarvis.app.live.WakeService
import com.jarvis.app.ui.components.*
import com.jarvis.app.ui.theme.*

@Composable
fun AssistantScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(Prefs.assistantName) }
    var phrase by remember { mutableStateOf(Prefs.wakePhrase) }
    var on by remember { mutableStateOf(Prefs.wakeEnabled) }
    var msg by remember { mutableStateOf("") }
    val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val overlayOk = Settings.canDrawOverlays(ctx)

    fun apply() {
        Prefs.assistantName = name.trim().ifBlank { "Jarvis" }
        Prefs.wakePhrase = phrase.trim()
        Prefs.wakeEnabled = on && phrase.isNotBlank()
        Prefs.save()
        if (Prefs.wakeEnabled) {
            if (!micOk) { msg = "Allow the microphone first (Control > Permissions)."; Prefs.wakeEnabled = false; on = false; Prefs.save(); return }
            WakeService.start(ctx)
            msg = if (overlayOk) "Listening in the background for “${Prefs.wakePhrase}”." else "Listening, but allow “Display over other apps” so the assistant can open over other screens."
        } else { WakeService.stop(ctx); msg = "Saved. Wake phrase is off." }
    }

    ScreenScaffold(null, {}) {
        SubHeader("Assistant", onBack)
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                JText("ASSISTANT NAME", 11, Gold, FontWeight.Medium, ls = 2.2f)
                JField(name, { name = it }, "Jarvis", Modifier.fillMaxWidth())
                JText("Any name you like. It is used in chat, calls and the spoken briefing.", 11, Muted, lh = 16)
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                JText("WAKE PHRASE", 11, Gold, FontWeight.Medium, ls = 2.2f)
                JField(phrase, { phrase = it }, "e.g. Hallo bro", Modifier.fillMaxWidth())
                JText("Say it out loud while the app is closed and the assistant opens over your screen, like Siri.", 11, Muted, lh = 16)
            }
            val shape = RoundedCornerShape(14.dp)
            Row(
                Modifier.fillMaxWidth().clip(shape).background(Surface1).border(1.dp, Gold.copy(alpha = 0.16f), shape).padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    JText("Listen in the background", 14, Ivory, FontWeight.Medium)
                    JText("Runs a small foreground service", 11, Muted)
                }
                JToggle(on) { on = it }
            }
            val card = RoundedCornerShape(18.dp)
            Column(Modifier.fillMaxWidth().clip(card).background(Surface1).border(1.dp, Gold.copy(alpha = 0.14f), card).padding(horizontal = 16.dp)) {
                StatusRow("Microphone", micOk)
                Hairline(0.1f)
                Row(Modifier.fillMaxWidth().clickable { if (!overlayOk) DeviceControl.open(ctx, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))) }) { Box(Modifier.weight(1f)) { StatusRow("Display over other apps", overlayOk) } }
            }
            if (msg.isNotEmpty()) JText(msg, 12, GoldLight, lh = 18)
            JText("Notes: this uses the phone's speech recognizer in a loop (needs internet, uses battery, shows the mic indicator and may beep on some phones). Some phone brands stop background apps: set Jarvis to “No restrictions” in battery settings.", 11, Muted, lh = 16)
            GoldButton("Save", null, { apply() }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun StatusRow(name: String, ok: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        JText(name, 14, Ivory, modifier = Modifier.weight(1f))
        Icon(if (ok) Icons.Outlined.CheckCircle else Icons.Outlined.ErrorOutline, null, tint = if (ok) Gold else Color(0xFFE0665C), modifier = Modifier.size(18.dp))
        JText(if (ok) "Allowed" else "Tap to allow", 11, if (ok) Gold else Color(0xFFE0665C))
    }
}
