package com.jarvis.app.live

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.jarvis.app.AssistantActivity
import com.jarvis.app.data.Prefs

/**
 * Listens in the background for your wake phrase (e.g. "Hallo bro"). When heard, the assistant opens over the current screen.
 * Uses Android's speech recognizer in a loop, so it needs internet, uses some battery and the system may show the mic indicator.
 */
class WakeService : Service() {
    companion object {
        @Volatile var paused = false
        @Volatile var running = false
        fun start(ctx: Context) {
            val i = Intent(ctx, WakeService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, WakeService::class.java)) }
        fun matches(heard: String, phrase: String): Boolean {
            fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()
            val h = norm(heard); val p = norm(phrase)
            if (p.isEmpty()) return false
            return h.contains(p) || h.replace(" ", "").contains(p.replace(" ", ""))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Prefs.init(this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("wake", "Wake word", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "wake").setContentTitle("${Prefs.assistantName} is listening")
            .setContentText("Say “${Prefs.wakePhrase}” to start").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(88, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(88, n)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        running = true
        main.post { listen() }
        return START_STICKY
    }

    private fun listen() {
        if (!running) return
        if (paused || !Prefs.wakeEnabled || Prefs.wakePhrase.isBlank()) { main.postDelayed({ listen() }, 1500); return }
        destroyRec()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { restart(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 500) }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                if (list.any { matches(it, Prefs.wakePhrase) }) trigger() else restart(300)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                if (list.any { matches(it, Prefs.wakePhrase) }) trigger()
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        try { r.startListening(i) } catch (e: Exception) { restart(1000) }
    }

    private fun restart(delay: Long) { destroyRec(); main.postDelayed({ listen() }, delay) }

    private fun trigger() {
        if (paused) return
        paused = true
        destroyRec()
        try {
            startActivity(Intent(this, AssistantActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
        } catch (e: Exception) { paused = false; restart(1500) }
    }

    private fun destroyRec() {
        rec?.let { try { it.cancel(); it.destroy() } catch (e: Exception) { } }
        rec = null
    }

    override fun onDestroy() { running = false; main.removeCallbacksAndMessages(null); destroyRec(); super.onDestroy() }
}
