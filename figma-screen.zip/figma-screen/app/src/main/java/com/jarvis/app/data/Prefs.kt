package com.jarvis.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.jarvis.app.ui.theme.Palettes
import org.json.JSONArray
import org.json.JSONObject

data class CustomVoice(val name: String, val base: String, val style: String)

/** All user settings, stored privately on the device. */
object Prefs {
    private lateinit var sp: SharedPreferences

    var apiKey by mutableStateOf("")
    var manualModel by mutableStateOf("")      // "" = Auto (best model for each task)
    var voice by mutableStateOf("Zephyr")      // Gemini prebuilt voice name
    var voiceLabel by mutableStateOf("Zephyr") // shown name (custom voices have their own)
    var voiceStyle by mutableStateOf("")       // style direction for custom voices
    var lang by mutableStateOf("en-US")
    var theme by mutableStateOf(0)
    var orbStyle by mutableStateOf(0)
    var userName by mutableStateOf("")
    var instructions by mutableStateOf("")
    var rememberChats by mutableStateOf(true)
    var assistantName by mutableStateOf("Jarvis")
    var wakePhrase by mutableStateOf("")
    var wakeEnabled by mutableStateOf(false)
    var onboarded by mutableStateOf(false)
    var greetOnHome by mutableStateOf(true)
    val memories = mutableStateListOf<String>()
    val customVoices = mutableStateListOf<CustomVoice>()

    fun init(c: Context) {
        sp = c.applicationContext.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        apiKey = sp.getString("key", "") ?: ""
        manualModel = sp.getString("manual", "") ?: ""
        voice = sp.getString("voice", "Zephyr") ?: "Zephyr"
        voiceLabel = sp.getString("vlabel", voice) ?: voice
        voiceStyle = sp.getString("vstyle", "") ?: ""
        lang = sp.getString("lang", "en-US") ?: "en-US"
        theme = sp.getInt("theme", 0)
        orbStyle = sp.getInt("orb", 0)
        userName = sp.getString("name", "") ?: ""
        instructions = sp.getString("instr", "") ?: ""
        rememberChats = sp.getBoolean("rem", true)
        assistantName = sp.getString("aname", "Jarvis") ?: "Jarvis"
        wakePhrase = sp.getString("wake", "") ?: ""
        wakeEnabled = sp.getBoolean("wakeOn", false)
        onboarded = sp.getBoolean("onb", false)
        greetOnHome = sp.getBoolean("greet", true)
        memories.clear()
        try {
            val a = JSONArray(sp.getString("mem", "[]"))
            for (i in 0 until a.length()) memories.add(a.getString(i))
        } catch (e: Exception) { }
        customVoices.clear()
        try {
            val a = JSONArray(sp.getString("cv", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                customVoices.add(CustomVoice(o.getString("n"), o.getString("b"), o.getString("s")))
            }
        } catch (e: Exception) { }
        applyTheme()
    }

    fun applyTheme() { Palettes.current = Palettes.all[theme.coerceIn(0, Palettes.all.lastIndex)] }

    fun save() {
        val cv = JSONArray()
        customVoices.forEach { cv.put(JSONObject().put("n", it.name).put("b", it.base).put("s", it.style)) }
        sp.edit()
            .putString("key", apiKey).putString("manual", manualModel)
            .putString("voice", voice).putString("vlabel", voiceLabel).putString("vstyle", voiceStyle)
            .putString("lang", lang).putInt("theme", theme).putInt("orb", orbStyle)
            .putString("name", userName).putString("instr", instructions).putBoolean("rem", rememberChats)
            .putString("aname", assistantName).putString("wake", wakePhrase).putBoolean("wakeOn", wakeEnabled)
            .putBoolean("onb", onboarded).putBoolean("greet", greetOnHome)
            .putString("mem", JSONArray(memories.toList()).toString()).putString("cv", cv.toString())
            .apply()
    }
}
