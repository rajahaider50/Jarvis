package com.jarvis.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Msg(
    val text: String, val user: Boolean, val error: Boolean = false,
    val image: ByteArray? = null, val hadImage: Boolean = false, val model: String? = null
)
data class SessionMeta(val id: String, var title: String, var ts: Long)

object ChatStore {
    val messages = mutableStateListOf<Msg>()
    val sessions = mutableStateListOf<SessionMeta>()
    var currentId by mutableStateOf("")
    var busy by mutableStateOf(false)
    var lastModel by mutableStateOf("")
    var lastError: String? = null
    private lateinit var dir: File

    fun init(ctx: Context) {
        dir = ctx.filesDir
        sessions.clear()
        try {
            val a = JSONArray(File(dir, "chat_index.json").takeIf { it.exists() }?.readText() ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i); sessions.add(SessionMeta(o.getString("id"), o.getString("t"), o.getLong("ts")))
            }
        } catch (e: Exception) { }
        if (sessions.isEmpty()) newSession() else open(sessions[0].id)
    }

    private fun saveIndex() {
        val a = JSONArray(); sessions.forEach { a.put(JSONObject().put("id", it.id).put("t", it.title).put("ts", it.ts)) }
        File(dir, "chat_index.json").writeText(a.toString())
    }

    private fun saveCurrent() {
        if (currentId.isEmpty()) return
        val a = JSONArray()
        messages.forEach {
            a.put(JSONObject().put("t", it.text).put("u", it.user).put("e", it.error)
                .put("i", it.hadImage || it.image != null).put("m", it.model ?: ""))
        }
        File(dir, "chat_$currentId.json").writeText(a.toString())
        saveIndex()
    }

    fun newSession() {
        if (currentId.isNotEmpty() && messages.isNotEmpty()) saveCurrent()
        if (currentId.isNotEmpty() && messages.isEmpty()) return
        val id = System.currentTimeMillis().toString()
        sessions.add(0, SessionMeta(id, "New chat", System.currentTimeMillis()))
        currentId = id; messages.clear(); saveIndex()
    }

    fun open(id: String) {
        if (currentId.isNotEmpty() && currentId != id) saveCurrent()
        currentId = id; messages.clear()
        try {
            val f = File(dir, "chat_$id.json")
            if (f.exists()) {
                val a = JSONArray(f.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    messages.add(Msg(o.getString("t"), o.getBoolean("u"), o.optBoolean("e"), null, o.optBoolean("i"), o.optString("m").ifEmpty { null }))
                }
            }
        } catch (e: Exception) { }
    }

    fun delete(id: String) {
        File(dir, "chat_$id.json").delete()
        sessions.removeAll { it.id == id }
        if (id == currentId) { currentId = ""; if (sessions.isEmpty()) newSession() else open(sessions[0].id) }
        saveIndex()
    }

    fun clearCurrent() { messages.clear(); saveCurrent() }

    fun systemPrompt(voice: Boolean): String {
        val sb = StringBuilder()
        sb.append("You are ${Prefs.assistantName}, a private AI concierge: elegant, calm, precise and discreet. ")
        if (Prefs.userName.isNotBlank()) sb.append("The user's name is ${Prefs.userName}. ")
        if (Prefs.memories.isNotEmpty()) sb.append("Known facts about the user: ${Prefs.memories.joinToString("; ")}. ")
        if (Prefs.instructions.isNotBlank()) sb.append("User's custom instructions: ${Prefs.instructions} ")
        sb.append("Always reply in the same language the user writes. ")
        sb.append(if (voice) "Answer in one to three short spoken sentences, no markdown." else "Be concise and clear. Use plain text.")
        return sb.toString()
    }

    private fun fail(m: String) { lastError = m; messages.add(Msg(m, false, true)) }

    /** Adds the user message, picks the best available model for the task automatically, returns the reply (or null). */
    suspend fun ask(text: String, image: ByteArray? = null, voice: Boolean = false): String? {
        messages.add(Msg(text, true, image = image))
        lastError = null
        if (sessions.firstOrNull { it.id == currentId }?.title == "New chat") {
            sessions.firstOrNull { it.id == currentId }?.let { it.title = text.take(40).ifBlank { "Image chat" } }
        }
        val key = Prefs.apiKey
        if (key.isBlank()) { fail("Add your Gemini API key in Profile > Gemini API."); saveCurrent(); return null }
        if (!ModelCatalog.ready) ModelCatalog.refresh()
        val model = ModelCatalog.pick(ModelCatalog.taskFor(text, image != null))
        if (model == null) { fail("No Gemini model is available for your key. Check Profile > Gemini API."); saveCurrent(); return null }
        busy = true; lastModel = model.id
        return try {
            val src = if (Prefs.rememberChats) messages.takeLast(24) else messages.takeLast(1)
            val turns = src.filter { !it.error }
                .map { GeminiClient.Turn(if (it.user) "user" else "model", it.text, it.image) }
                .dropWhile { it.role == "model" }
            val r = GeminiClient.chat(key, model.id, systemPrompt(voice), turns)
            messages.add(Msg(r, false, model = model.id)); saveCurrent(); r
        } catch (e: CancellationException) { throw e
        } catch (e: Exception) { fail(e.message ?: "Request failed"); saveCurrent(); null
        } finally { busy = false }
    }
}
