package com.jarvis.app.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.jarvis.app.data.GeminiClient
import com.jarvis.app.data.ModelCatalog
import com.jarvis.app.data.Prefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import kotlin.coroutines.resume

/** Speaks text with the chosen Gemini voice; falls back to the phone's own voice if Gemini TTS is unavailable. */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    var lastError: String? = null

    fun init(ctx: Context) {
        if (tts == null) tts = TextToSpeech(ctx.applicationContext) { ready = (it == TextToSpeech.SUCCESS) }
    }

    suspend fun speak(text: String, voice: String = Prefs.voice, style: String = Prefs.voiceStyle) {
        val key = Prefs.apiKey
        val model = ModelCatalog.ttsModel()
        if (key.isNotBlank() && model != null) {
            try {
                PcmPlayer.play(GeminiClient.tts(key, model, voice, if (style.isBlank()) text else "$style: $text"))
                lastError = null
                return
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { lastError = e.message }
        }
        speakLocal(text)
    }

    suspend fun speakLocal(text: String) = suspendCancellableCoroutine<Unit> { cont ->
        val t = tts
        if (t == null || !ready) { cont.resume(Unit); return@suspendCancellableCoroutine }
        t.setLanguage(Locale.forLanguageTag(Prefs.lang))
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { if (cont.isActive) cont.resume(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { if (cont.isActive) cont.resume(Unit) }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, System.nanoTime().toString())
        cont.invokeOnCancellation { t.stop() }
    }
}
