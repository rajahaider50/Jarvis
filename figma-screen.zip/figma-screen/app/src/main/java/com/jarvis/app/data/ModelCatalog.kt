package com.jarvis.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.jarvis.app.data.GeminiClient.ModelInfo
import kotlinx.coroutines.CancellationException

/** Real models available for the user's key (from models.list) + automatic per-task selection. */
object ModelCatalog {
    var chat by mutableStateOf(listOf<ModelInfo>())
    var tts by mutableStateOf(listOf<ModelInfo>())
    var live by mutableStateOf(listOf<ModelInfo>())
    var loading by mutableStateOf(false)
    var ok by mutableStateOf<Boolean?>(null)
    var status by mutableStateOf("")

    val ready get() = chat.isNotEmpty()

    enum class Task { FAST, IMAGE, COMPLEX }

    suspend fun refresh() {
        val key = Prefs.apiKey.trim()
        if (key.isEmpty()) { ok = null; status = "Add your API key first"; return }
        loading = true; status = "Contacting Google…"
        try {
            val all = GeminiClient.listModels(key)
            chat = GeminiClient.sortChat(all.filter { GeminiClient.isChat(it) })
            tts = all.filter { GeminiClient.isTts(it) }.sortedByDescending { it.id }
            live = all.filter { GeminiClient.isLive(it) }.sortedByDescending { it.id }
            ok = chat.isNotEmpty()
            status = if (chat.isNotEmpty()) "Connected · ${chat.size} chat · ${tts.size} voice · ${live.size} live models"
            else "This key has no Gemini chat models"
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ok = false; status = e.message ?: "Connection failed"
        }
        loading = false
    }

    private fun stable(f: (ModelInfo) -> Boolean): ModelInfo? =
        chat.firstOrNull { f(it) && "preview" !in it.id && "exp" !in it.id } ?: chat.firstOrNull(f)

    fun pick(task: Task): ModelInfo? {
        val m = Prefs.manualModel
        if (m.isNotBlank()) chat.firstOrNull { it.id == m }?.let { return it }
        if (chat.isEmpty()) return null
        return when (task) {
            Task.COMPLEX -> stable { "pro" in it.id } ?: stable { "flash" in it.id && "lite" !in it.id } ?: chat.first()
            Task.IMAGE -> stable { "flash" in it.id && "lite" !in it.id } ?: stable { "pro" in it.id } ?: chat.first()
            Task.FAST -> stable { "flash-lite" in it.id } ?: stable { "flash" in it.id } ?: chat.first()
        }
    }

    fun taskFor(text: String, hasImage: Boolean): Task {
        if (hasImage) return Task.IMAGE
        val l = text.lowercase()
        val keys = listOf("code", "analy", "explain in detail", "step by step", "compare", "essay", "plan ", "strategy",
            "calculate", "prove", "algorithm", "debug", "research", "تفصیل", "تجزیہ", "کوڈ", "موازنہ")
        return if (text.length > 350 || keys.any { it in l }) Task.COMPLEX else Task.FAST
    }

    fun ttsModel(): String? = tts.firstOrNull { "flash" in it.id }?.id ?: tts.firstOrNull()?.id
    fun liveModel(): String? = live.firstOrNull { "flash" in it.id }?.id ?: live.firstOrNull()?.id
}
