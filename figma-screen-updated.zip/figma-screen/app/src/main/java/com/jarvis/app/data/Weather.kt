package com.jarvis.app.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Today's weather from Open-Meteo (free, no key) using the phone's last known location. */
object Weather {
    private fun lastLocation(ctx: Context): Location? {
        val ok = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!ok) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            try {
                val l = lm.getLastKnownLocation(p)
                if (l != null && (best == null || l.time > best.time)) best = l
            } catch (e: SecurityException) { } catch (e: Exception) { }
        }
        return best
    }

    private fun describe(code: Int) = when (code) {
        0 -> "clear sky"; 1, 2 -> "mostly clear"; 3 -> "overcast"; 45, 48 -> "foggy"
        in 51..57 -> "drizzle"; in 61..67 -> "rain"; in 71..77 -> "snow"; in 80..82 -> "rain showers"
        85, 86 -> "snow showers"; in 95..99 -> "thunderstorm"; else -> "mixed weather"
    }

    suspend fun fetch(ctx: Context): String? = withContext(Dispatchers.IO) {
        try {
            val loc = lastLocation(ctx) ?: return@withContext null
            val url = URL("https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=temperature_2m,weather_code&timezone=auto")
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 5000
            val cur = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getJSONObject("current")
            "${describe(cur.getInt("weather_code"))}, ${cur.getDouble("temperature_2m").toInt()} degrees Celsius"
        } catch (e: Exception) { null }
    }
}
