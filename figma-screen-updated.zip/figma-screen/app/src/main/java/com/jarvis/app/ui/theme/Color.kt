package com.jarvis.app.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

data class Palette(
    val name: String, val accent: Long, val light: Long, val dark: Long,
    val bg: Long, val s1: Long, val s2: Long
)

/** 15 color styles. The first one is the original Figma "Royal Gold". */
object Palettes {
    val all = listOf(
        Palette("Royal Gold", 0xFFC9A84C, 0xFFEBD48F, 0xFFA98531, 0xFF0B0B0D, 0xFF151518, 0xFF202024),
        Palette("Rose Gold", 0xFFD4A28E, 0xFFF2CBB8, 0xFFA8725F, 0xFF0D0A0A, 0xFF181314, 0xFF241C1E),
        Palette("Platinum", 0xFFC9CED6, 0xFFEEF1F5, 0xFF8E96A3, 0xFF0A0B0D, 0xFF141518, 0xFF1F2126),
        Palette("Emerald", 0xFF3FBF8F, 0xFF8FE8C3, 0xFF1F8A63, 0xFF070D0B, 0xFF0F1814, 0xFF17251F),
        Palette("Sapphire", 0xFF4C8DEB, 0xFF9CC3FA, 0xFF2C62B5, 0xFF070A10, 0xFF0F1420, 0xFF171E30),
        Palette("Amethyst", 0xFFA57BEA, 0xFFD2B8FA, 0xFF7447B8, 0xFF0B080F, 0xFF15101E, 0xFF20182E),
        Palette("Ruby", 0xFFE0455A, 0xFFF59AA7, 0xFFA82A3C, 0xFF0F0709, 0xFF1C0F13, 0xFF2A171C),
        Palette("Copper", 0xFFC8773E, 0xFFEBAA7A, 0xFF94521F, 0xFF0E0A07, 0xFF19120D, 0xFF261C15),
        Palette("Teal", 0xFF2FB5BF, 0xFF8CE0E6, 0xFF1B7F88, 0xFF060D0E, 0xFF0E1A1C, 0xFF15272A),
        Palette("Sunset", 0xFFF08A4B, 0xFFFFC08F, 0xFFC2551F, 0xFF0F0A07, 0xFF1B120C, 0xFF291B12),
        Palette("Ice Blue", 0xFF7FC8F0, 0xFFC6E8FA, 0xFF4C93BF, 0xFF070B0F, 0xFF101820, 0xFF18242F),
        Palette("Champagne", 0xFFE6D3A8, 0xFFFAF0D6, 0xFFB79F68, 0xFF0C0B09, 0xFF171512, 0xFF231F1A),
        Palette("Onyx Mono", 0xFFE8E8E8, 0xFFFFFFFF, 0xFF9A9A9A, 0xFF050505, 0xFF101010, 0xFF1A1A1A),
        Palette("Orchid", 0xFFE58FD0, 0xFFF6C4EA, 0xFFB5589F, 0xFF0D080C, 0xFF1B1019, 0xFF291A27),
        Palette("Olive Luxe", 0xFFB5B85A, 0xFFDADE8C, 0xFF7F8230, 0xFF0B0C07, 0xFF15170E, 0xFF202316)
    )
    var current by mutableStateOf(all[0])
}

// Dynamic colors: every screen reads these, so changing the palette updates the whole app.
val Bg: Color get() = Color(Palettes.current.bg)
val Surface1: Color get() = Color(Palettes.current.s1)
val Surface2: Color get() = Color(Palettes.current.s2)
val Gold: Color get() = Color(Palettes.current.accent)
val GoldLight: Color get() = Color(Palettes.current.light)
val GoldDark: Color get() = Color(Palettes.current.dark)
val Ivory = Color(0xFFF5F0E6)
val Muted = Color(0xFF8E897D)
