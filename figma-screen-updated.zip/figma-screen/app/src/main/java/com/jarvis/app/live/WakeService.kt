package com.jarvis.app.live

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.jarvis.app.AssistantActivity
import com.jarvis.app.MainActivity
import com.jarvis.app.data.Prefs

/**
 * Listens in the background for your wake phrase (any name / command you chose). When heard, the assistant orb opens over the
 * current screen (like Siri). Uses Android's speech recognizer in a loop, so it needs internet and shows the mic indicator.
 */
class WakeService : Service() {
    companion object {
        @Volatile var paused = false
        @Volatile var running = false
        private var inst: WakeService? = null

        /** Pause = release the microphone right now (used by the live call and the assistant panel). */
        fun setPaused(p: Boolean) {
            paused = p
            if (p) inst?.let { s -> s.main.post { s.destroyRec(); s.schedule(1000) } }
        }

        fun start(ctx: Context) {
            val i = Intent(ctx, WakeService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, WakeService::class.java)) }

        private fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

        private fun lev(a: String, b: String): Int {
            if (a == b) return 0
            var prev = IntArray(b.length + 1) { it }
            for (i in 1..a.length) {
                val cur = IntArray(b.length + 1); cur[0] = i
                for (j in 1..b.length) cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = cur
            }
            return prev[b.length]
        }

        /** Exact match, or a close match (speech recognizers often hear "my up" for "my app"). */
        fun matches(heard: String, phrase: String): Boolean {
            val h = norm(heard); val p = norm(phrase)
            if (p.isEmpty() || h.isEmpty()) return false
            val pc = p.replace(" ", "")
            if (h.contains(p) || h.replace(" ", "").contains(pc)) return true
            if (pc.length < 4) return false
            val hw = h.split(" ")
            val n = p.split(" ").size
            val allowed = maxOf(1, pc.length / 4)
            for (size in maxOf(1, n - 1)..(n + 1)) {
                if (size > hw.size) continue
                for (i in 0..(hw.size - size)) {
                    val w = hw.subList(i, i + size).joinToString("")
                    if (lev(w, pc) <= allowed) return true
                }
            }
            return false
        }

        /** Language used to hear the wake phrase: the one you picked, otherwise guessed from the phrase's script. */
        fun wakeLocale(): String {
            if (Prefs.wakeLang != "auto") return Prefs.wakeLang
            val p = Prefs.wakePhrase
            return when {
                p.any { it in '\u0600'..'\u06FF' } -> if (Prefs.lang == "ar-SA") "ar-SA" else "ur-PK"
                p.any { it in '\u0900'..'\u097F' } -> "hi-IN"
                p.any { it in '\u0400'..'\u04FF' } -> "ru-RU"
                else -> if (Prefs.lang in listOf("en-US", "es-ES", "fr-FR", "tr-TR")) Prefs.lang else "en-US"
            }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private val am by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private val mutedStreams = mutableListOf<Int>()
    private val unmuteTask = Runnable { unmuteBeeps() }
    private val loop = Runnable { listen() }
    private fun schedule(delay: Long) { main.removeCallbacks(loop); main.postDelayed(loop, delay) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Prefs.init(this)
        inst = this
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("wake", "Wake word", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "wake").setContentTitle("${Prefs.assistantName} is listening")
            .setContentText("Say “${Prefs.wakePhrase}” to start").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open).setOngoing(true).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(88, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(88, n)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        running = true
        main.removeCallbacksAndMessages(null)
        schedule(0)
        return START_STICKY
    }

    // ---- silence the recognizer's start/stop "tonk" sounds (only for a moment, so music and ringtones are not affected) ----
    private fun muteBeeps(forMs: Long) {
        main.removeCallbacks(unmuteTask)
        if (mutedStreams.isEmpty()) {
            val streams = if (am.isMusicActive) listOf(AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION)
            else listOf(AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_MUSIC)
            for (s in streams) {
                try {
                    if (!am.isStreamMute(s)) { am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0); mutedStreams.add(s) }
                } catch (e: Exception) { }
            }
        }
        main.postDelayed(unmuteTask, forMs)
    }

    private fun unmuteBeeps() {
        for (s in mutedStreams) { try { am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0) } catch (e: Exception) { } }
        mutedStreams.clear()
    }

    private fun listen() {
        if (!running) return
        if (paused || !Prefs.wakeEnabled || Prefs.wakePhrase.isBlank()) { schedule(1000); return }
        destroyRec()
        muteBeeps(1100)
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { muteBeeps(900) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { muteBeeps(1000) }
            override fun onError(error: Int) {
                muteBeeps(1000)
                restart(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 200)
            }
            override fun onResults(results: Bundle?) {
                muteBeeps(1000)
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                if (list.any { matches(it, Prefs.wakePhrase) }) trigger() else restart(150)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                if (list.any { matches(it, Prefs.wakePhrase) }) trigger()
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, wakeLocale())
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, wakeLocale())
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        try { r.startListening(i) } catch (e: Exception) { restart(1000) }
    }

    private fun restart(delay: Long) { destroyRec(); schedule(delay) }

    private fun trigger() {
        if (paused) return
        paused = true
        destroyRec()
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) { }
        val intent = Intent(this, AssistantActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        // 1) direct start (works when "Display over other apps" is allowed)  2) full-screen notification as a backup
        try { startActivity(intent) } catch (e: Exception) { }
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("assistant", "Assistant", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(this, 1, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            nm.notify(89, Notification.Builder(this, "assistant").setContentTitle(Prefs.assistantName).setContentText("Tap to talk")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setCategory(Notification.CATEGORY_CALL)
                .setFullScreenIntent(pi, true).setContentIntent(pi).setAutoCancel(true).build())
        } catch (e: Exception) { }
        // if Android blocked the background start, do not stay deaf: resume listening
        main.postDelayed({
            if (!AssistantActivity.alive) { paused = false; restart(300) }
        }, 3500)
    }

    private fun destroyRec() {
        rec?.let { try { it.cancel(); it.destroy() } catch (e: Exception) { } }
        rec = null
    }

    override fun onDestroy() {
        running = false; inst = null
        main.removeCallbacksAndMessages(null)
        unmuteBeeps(); destroyRec()
        super.onDestroy()
    }
}
