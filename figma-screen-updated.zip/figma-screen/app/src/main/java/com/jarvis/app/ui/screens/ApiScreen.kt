package com.jarvis.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.jarvis.app.data.ModelCatalog
import com.jarvis.app.data.Prefs
import com.jarvis.app.ui.components.*
import com.jarvis.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ApiScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf(Prefs.apiKey) }
    var show by remember { mutableStateOf(false) }
    var showAll by remember { mutableStateOf(false) }

    ScreenScaffold(null, {}) {
        SubHeader("Gemini API", onBack)
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (ModelCatalog.status.isNotEmpty()) {
                val c = when (ModelCatalog.ok) { true -> Gold; false -> Color(0xFFE0665C); else -> Muted }
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.copy(alpha = 0.1f)).border(1.dp, c.copy(alpha = 0.35f), RoundedCornerShape(14.dp)).padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(8.dp).background(c, CircleShape))
                    JText(ModelCatalog.status, 13, if (ModelCatalog.ok == true) GoldLight else Ivory, FontWeight.Medium, lh = 19, modifier = Modifier.weight(1f))
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                JText("API KEY", 11, Gold, FontWeight.Medium, ls = 2.2f)
                JField(key, { key = it }, "Paste your Gemini API key", Modifier.fillMaxWidth(), secret = !show, trailing = {
                    Icon(Icons.Outlined.Visibility, "Show", tint = if (show) Gold else Muted, modifier = Modifier.size(20.dp).clickable { show = !show })
                })
                JText("Free key: aistudio.google.com → Get API key", 11, Muted)
            }
            GoldButton(if (ModelCatalog.loading) "Loading…" else "Save & Connect", Icons.Outlined.Refresh, {
                if (!ModelCatalog.loading && key.isNotBlank()) scope.launch { Prefs.apiKey = key.trim(); Prefs.save(); ModelCatalog.refresh() }
            }, Modifier.fillMaxWidth())

            JText("AUTOMATIC MODELS", 11, Gold, FontWeight.Medium, ls = 2.2f)
            JText("Nothing to select: Jarvis reads the real model list of your key and picks the best available model for each job.", 11, Muted, lh = 16)
            val card = RoundedCornerShape(18.dp)
            Column(Modifier.fillMaxWidth().clip(card).background(Surface1).border(1.dp, Gold.copy(alpha = 0.16f), card).padding(horizontal = 14.dp)) {
                AutoRow("Quick questions", ModelCatalog.pick(ModelCatalog.Task.FAST)?.id)
                Hairline(0.1f)
                AutoRow("Photos & vision", ModelCatalog.pick(ModelCatalog.Task.IMAGE)?.id)
                Hairline(0.1f)
                AutoRow("Complex reasoning", ModelCatalog.pick(ModelCatalog.Task.COMPLEX)?.id)
                Hairline(0.1f)
                AutoRow("Voice (speech)", ModelCatalog.ttsModel())
                Hairline(0.1f)
                AutoRow("Live call", ModelCatalog.liveModel())
            }
            Row(Modifier.clickable { showAll = !showAll }, horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                JText(if (showAll) "Hide manual override" else "Manual override (optional)", 12, Gold, FontWeight.Medium)
                Icon(if (showAll) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore, null, tint = Gold, modifier = Modifier.size(16.dp))
            }
            if (showAll) {
                Column(Modifier.fillMaxWidth().clip(card).background(Surface1).border(1.dp, Gold.copy(alpha = 0.16f), card).padding(horizontal = 14.dp)) {
                    Row(Modifier.fillMaxWidth().clickable { Prefs.manualModel = ""; Prefs.save() }.padding(vertical = 11.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        JRadio(Prefs.manualModel.isBlank()); JText("Auto (recommended)", 14, Ivory, FontWeight.Medium)
                    }
                    ModelCatalog.chat.forEach { m ->
                        Hairline(0.1f)
                        Row(Modifier.fillMaxWidth().clickable { Prefs.manualModel = m.id; Prefs.save() }.padding(vertical = 11.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            JRadio(Prefs.manualModel == m.id); JText(m.id, 13, Ivory)
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun AutoRow(label: String, model: String?) {
    Row(Modifier.fillMaxWidth().padding(vertical = 11.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        JText(label, 13, Ivory)
        JText(model ?: "not available", 11, if (model != null) Gold else Muted, modifier = Modifier.padding(start = 12.dp))
    }
}
