package com.jarvis.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Gold, onPrimary = Bg, background = Bg, onBackground = Ivory,
        surface = Surface1, onSurface = Ivory
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
