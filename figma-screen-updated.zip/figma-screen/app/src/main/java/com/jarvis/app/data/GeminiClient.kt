package com.jarvis.app.data

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Minimal Gemini API client (REST, v1beta). No model names are hard-coded:
 * the list of usable models always comes from models.list for the user's own key.
 */
object GeminiClient {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"

    class GeminiHttpException(val code: Int, msg: String) : IOException("HTTP $code: $msg")

    data class ModelInfo(val id: String, val display: String, val methods: List<String>)

    private fun call(path: String, key: String, body: String?, readMs: Int = 90000): String {
        val conn = URL("$BASE/$path").openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = readMs
        conn.setRequestProperty("x-goog-api-key", key)
        conn.setRequestProperty("Content-Type", "application/json")
        if (body != null) {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        } else {
            conn.requestMethod = "GET"
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).getJSONObject("error").getString("message")
            } catch (e: Exception) { text.take(200) }
            throw GeminiHttpException(code, msg)
        }
        return text
    }

    suspend fun listModels(key: String): List<ModelInfo> = withContext(Dispatchers.IO) {
        val out = mutableListOf<ModelInfo>()
        var token: String? = null
        do {
            val path = "models?pageSize=1000" + (token?.let { "&pageToken=$it" } ?: "")
            val j = JSONObject(call(path, key, null))
            val arr = j.optJSONArray("models") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                val ms = m.optJSONArray("supportedGenerationMethods")
                val methods = ArrayList<String>()
                if (ms != null) for (k in 0 until ms.length()) methods.add(ms.getString(k))
                out.add(ModelInfo(m.getString("name").removePrefix("models/"), m.optString("displayName"), methods))
            }
            val next = j.optString("nextPageToken", "")
            token = if (next.isEmpty()) null else next
        } while (token != null)
        out
    }

    private val notChat = listOf("tts", "image", "live", "audio", "embedding", "robotics", "computer", "imagen", "veo", "native")
    fun isChat(m: ModelInfo) = m.id.startsWith("gemini") && "generateContent" in m.methods && notChat.none { it in m.id }
    fun isLive(m: ModelInfo) = "bidiGenerateContent" in m.methods
    fun isTts(m: ModelInfo) = "tts" in m.id && "generateContent" in m.methods

    fun sortChat(l: List<ModelInfo>) = l.sortedByDescending { it.id }

    fun pickDefault(chat: List<ModelInfo>): ModelInfo =
        chat.firstOrNull { "flash" in it.id && "lite" !in it.id && "preview" !in it.id && "exp" !in it.id }
            ?: chat.firstOrNull { "flash" in it.id && "lite" !in it.id && "preview" !in it.id && "exp" !in it.id }
            ?: chat.firstOrNull { "flash" in it.id }
            ?: chat.first()

    fun pickTts(tts: List<ModelInfo>): ModelInfo? = tts.firstOrNull { "flash" in it.id } ?: tts.firstOrNull()

    data class Turn(val role: String, val text: String, val image: ByteArray? = null)

    suspend fun chat(key: String, model: String, system: String, turns: List<Turn>): String =
        withContext(Dispatchers.IO) {
            val contents = JSONArray()
            turns.forEach { t ->
                val parts = JSONArray()
                if (t.image != null) parts.put(JSONObject().put("inlineData",
                    JSONObject().put("mimeType", "image/jpeg").put("data", Base64.encodeToString(t.image, Base64.NO_WRAP))))
                parts.put(JSONObject().put("text", t.text.ifBlank { "Describe this image." }))
                contents.put(JSONObject().put("role", t.role).put("parts", parts))
            }
            val body = JSONObject()
                .put("contents", contents)
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .toString()
            val j = JSONObject(call("models/$model:generateContent", key, body))
            val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (!p.optBoolean("thought", false)) sb.append(p.optString("text", ""))
            }
            val reply = sb.toString().trim()
            if (reply.isEmpty()) throw IOException("Empty reply (the answer may have been blocked)")
            reply
        }

    /** Returns raw PCM (16-bit, mono, 24 kHz) of the spoken text. */
    suspend fun tts(key: String, model: String, voice: String, text: String): ByteArray =
        withContext(Dispatchers.IO) {
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
                .put("generationConfig", JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put("speechConfig", JSONObject().put("voiceConfig",
                        JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
                .toString()
            val j = JSONObject(call("models/$model:generateContent", key, body, 45000))
            val cand = j.optJSONArray("candidates")?.optJSONObject(0)
            val parts = cand?.optJSONObject("content")?.optJSONArray("parts")
            var data: String? = null
            if (parts != null) for (i in 0 until parts.length()) {
                val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data")
                if (!d.isNullOrEmpty()) { data = d; break }
            }
            if (data == null) throw IOException("No audio returned (" + (cand?.optString("finishReason") ?: "empty reply") + ")")
            Base64.decode(data, Base64.DEFAULT)
        }
}
