package com.jarvis.app.ui.screens

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.app.data.ChatStore
import com.jarvis.app.data.ImageUtil
import com.jarvis.app.data.ModelCatalog
import com.jarvis.app.data.Msg
import com.jarvis.app.data.Prefs
import com.jarvis.app.ui.components.*
import com.jarvis.app.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(onNav: (String) -> Unit) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<ByteArray?>(null) }
    var showHistory by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val scroll = rememberScrollState()
    val msgs = ChatStore.messages
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) pending = ImageUtil.fromUri(ctx, uri)
    }

    fun send(text: String) {
        val t = text.trim(); val img = pending
        if ((t.isEmpty() && img == null) || ChatStore.busy) return
        pending = null
        scope.launch { ChatStore.ask(t, img, false) }
    }
    LaunchedEffect(msgs.size, ChatStore.busy) { scroll.animateScrollTo(scroll.maxValue) }

    ScreenScaffold("chat", onNav) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(40.dp).background(goldBrush(), CircleShape), contentAlignment = Alignment.Center) { JText(Prefs.assistantName.take(1).uppercase(), 19, Bg, FontWeight.Medium, serif = true) }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                JText(Prefs.assistantName, 18, Ivory, FontWeight.Medium, serif = true)
                Box {
                    Row(Modifier.clickable { menu = true }, horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).background(Gold, CircleShape))
                        JText(
                            if (Prefs.manualModel.isNotBlank()) Prefs.manualModel
                            else "Auto · ${ChatStore.lastModel.ifBlank { "best model for each task" }}", 11, GoldLight
                        )
                        Icon(Icons.Outlined.ExpandMore, null, tint = GoldLight, modifier = Modifier.size(14.dp))
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { JText("Auto (best model for each task)", 13, if (Prefs.manualModel.isBlank()) Gold else Ivory) }, onClick = { Prefs.manualModel = ""; Prefs.save(); menu = false })
                        ModelCatalog.chat.forEach { m ->
                            DropdownMenuItem(text = { JText(m.id, 13, if (Prefs.manualModel == m.id) Gold else Ivory) }, onClick = { Prefs.manualModel = m.id; Prefs.save(); menu = false })
                        }
                    }
                }
            }
            Icon(Icons.Outlined.History, "History", tint = if (showHistory) Gold else Ivory, modifier = Modifier.size(24.dp).clickable { showHistory = !showHistory })
            Icon(Icons.Outlined.Add, "New chat", tint = Ivory, modifier = Modifier.size(26.dp).clickable { ChatStore.newSession(); showHistory = false })
        }
        Hairline()
        if (showHistory) {
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                JText("CHAT HISTORY", 11, Gold, FontWeight.Medium, ls = 2.2f)
                val fmt = remember { SimpleDateFormat("dd MMM · HH:mm", Locale.getDefault()) }
                ChatStore.sessions.toList().forEach { s ->
                    val shape = RoundedCornerShape(16.dp)
                    Row(
                        Modifier.fillMaxWidth().clip(shape).background(Surface1)
                            .border(1.dp, Gold.copy(alpha = if (s.id == ChatStore.currentId) 0.7f else 0.14f), shape)
                            .clickable { ChatStore.open(s.id); showHistory = false }.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            JText(s.title, 14, Ivory, FontWeight.Medium); JText(fmt.format(Date(s.ts)), 11, Muted)
                        }
                        Icon(Icons.Outlined.Delete, "Delete", tint = Muted, modifier = Modifier.size(20.dp).clickable { ChatStore.delete(s.id) })
                    }
                }
            }
        } else {
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(scroll).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Bubble(Msg("Good evening, ${Prefs.userName.ifBlank { "there" }}. How may I assist you? You can type, attach a photo, or tap the mic for a live call.", false), 290)
                msgs.forEach { Bubble(it, if (it.user) 260 else 310) }
                if (ChatStore.busy) Bubble(Msg("…", false, model = "using ${ChatStore.lastModel}"), 200)
                if (msgs.isEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("What can you do?", "Plan my day", "Tell me a fact").forEach { s ->
                            Box(Modifier.clip(RoundedCornerShape(18.dp)).border(1.dp, Gold.copy(alpha = 0.45f), RoundedCornerShape(18.dp)).clickable { send(s) }.padding(horizontal = 12.dp, vertical = 8.dp)) { JText(s, 12, Gold) }
                        }
                    }
                }
            }
        }
        Hairline()
        pending?.let { img ->
            val bmp = remember(img) { BitmapFactory.decodeByteArray(img, 0, img.size) }
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                JText("Image attached", 12, Muted, modifier = Modifier.weight(1f))
                Icon(Icons.Outlined.Close, "Remove", tint = Muted, modifier = Modifier.size(20.dp).clickable { pending = null })
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(44.dp).background(Surface1, CircleShape).border(1.dp, Gold.copy(alpha = 0.25f), CircleShape)
                .clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Image, "Attach photo", tint = Gold, modifier = Modifier.size(20.dp))
            }
            val fieldShape = RoundedCornerShape(26.dp)
            Row(
                Modifier.weight(1f).clip(fieldShape).background(Surface1).border(1.dp, Gold.copy(alpha = 0.22f), fieldShape).padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                    textStyle = TextStyle(color = Ivory, fontSize = 14.sp), cursorBrush = SolidColor(Gold), maxLines = 4,
                    decorationBox = { inner -> Box { if (input.isEmpty()) JText("Ask Jarvis anything…", 14, Muted); inner() } }
                )
                Icon(Icons.Outlined.Mic, "Live call", tint = Gold, modifier = Modifier.size(22.dp).clickable { onNav("live") })
            }
            Box(Modifier.size(46.dp).background(goldBrush(), CircleShape).clickable { val t = input; input = ""; send(t) }, contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Send, "Send", tint = Bg, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
private fun Bubble(m: Msg, maxW: Int) {
    val user = m.user
    val shape = if (user) RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp) else RoundedCornerShape(4.dp, 18.dp, 18.dp, 18.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = maxW.dp).clip(shape)
                .then(if (user) Modifier.background(goldBrush()) else Modifier.background(Surface1).border(1.dp, (if (m.error) Color(0xFFE0665C) else Gold).copy(alpha = if (m.error) 0.5f else 0.14f), shape))
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            m.image?.let { img ->
                val bmp = remember(img) { BitmapFactory.decodeByteArray(img, 0, img.size) }
                if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 200.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
            }
            if (m.image == null && m.hadImage) JText("[photo]", 12, if (user) Bg else Muted)
            if (m.text.isNotBlank()) JText(m.text, 14, if (user) Bg else if (m.error) Color(0xFFF0A59E) else Ivory, if (user) FontWeight.Medium else FontWeight.Normal, lh = 21)
            if (!user && !m.error && m.model != null) JText(m.model, 10, Muted)
        }
    }
}
