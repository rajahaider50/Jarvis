# Jarvis - Luxury AI Assistant (Android, Jetpack Compose)

Figma: https://www.figma.com/design/0voJxKEm57v1bjJLRXXCV4

## Update 4
- First run: Intro -> Language -> Permissions -> Gemini API -> System setup (real 0-100% loading) -> Dashboard. Next runs open Home directly.
- Home: premium loading popup on app start (real stages: connect, device status, weather, briefing, voice) then Jarvis speaks automatically.
  Coming back to Home plays the cached briefing instantly. The speaker button replays it. Tapping the current tab does nothing (no flicker).
- Live call audio: Auto / Speaker / Ear / Bluetooth / Wired. Auto = loudspeaker normally, earpiece when the phone is at your ear (proximity sensor),
  Bluetooth or wired headset when connected.
- Assistant name + wake phrase (Profile > Assistant name & wake phrase). Background listening opens a Siri-style panel over any screen.
- Custom premium icon set (design/icons/*.svg, res/drawable/ic_*.xml). Import design/icons/_icon_sheet.svg into Figma to edit them.

## What works
- **Home**: animated boot sequence (orb, rotating rings, status lines), Jarvis speaks a greeting with REAL phone data:
  battery %, battery temperature + thermal status, free storage, free RAM (no special permission needed). Equal-size tiles.
- **Live Call** (mic button): Gemini Live API over WebSocket. Continuous voice-to-voice (no push-to-talk), Siri-style orb + voice wave layers,
  language chips (8 languages) you can tap at any time, mic mute, **front/back camera**, **screen sharing** (MediaProjection), phone tools by voice
  (flashlight, volume, device status).
- **Chat**: real Gemini replies, **automatic model per task** (quick / photo / complex), optional manual model menu, **chat history** (new / open / delete),
  **photo upload**.
- **Control**: real flashlight, volume, ringer, brightness, Do Not Disturb, quick links to Wi-Fi / Bluetooth / Airplane / Location panels
  (Android does not allow apps to switch Wi-Fi/Bluetooth directly), permission status + grant buttons.
- **Profile**: Gemini API (auto models), Voice (16 voices, 8 languages, loading popup 0-100%, custom voices), Appearance (16 orb styles + 15 colors), Memory.

## Gemini API (no fake models)
1. Free key: https://aistudio.google.com -> Get API key.
2. App -> Profile -> Gemini API -> paste key -> Save & Connect.
3. The model list comes live from Google (`models.list`) for YOUR key. Jarvis picks the best available model for each job automatically
   (fast / vision / reasoning / voice / live). Nothing is hard-coded.

## Build the APK from a phone (no PC)
1. Create a GitHub repo and upload all files of this zip (keep folders). Easiest on phone: Termux
   ```
   pkg install git unzip
   unzip figma-screen.zip && cd figma-screen
   git init && git add . && git commit -m "Jarvis"
   git branch -M main
   git remote add origin https://github.com/USERNAME/REPO.git
   git push -u origin main
   ```
2. Repo -> Actions -> "Build APK" -> Run. After 2-5 min download Artifacts -> `jarvis-debug-apk`.
3. Install `app-debug.apk`. Allow Microphone / Camera / Notifications when asked.

## Notes
- minSdk 26 (Android 8+). Needs internet.
- Live API and Gemini voices need a key/plan that allows them; the app shows exactly what your key supports.
- If the Live connection fails the app retries with alternative setup layouts and shows Google's error message.
- This code could not be compiled/tested in the authoring environment. If the first build fails, send the Actions log.
- Not included: Accessibility Service (not needed for the features above; can be added later).

## Update 5
- Removed the phone/Google text-to-speech completely. All speech now comes from Gemini voices (`audio/Speaker.kt`).
- `Speaker.synth` picks the voice model automatically from your API key's model list and tries the next one on quota/errors.
- Wake word: hears the phrase in the right language (Assistant > Wake phrase language), fuzzy matching, beep muting, full-screen-notification backup, battery row. Allow: Microphone, Display over other apps, Battery no restrictions.
